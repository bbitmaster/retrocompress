/*
 *	Compresch - compression library
 *  Copyright 2008 Disch
 *  See license.txt for details
 */


#ifndef __BLOCK_LZ_H__
#define __BLOCK_LZ_H__


/*
 *	LZ -- Basic LZ copy.  2-byte absolute address to copy from
 *
 *  if @ 0816:  16 18 EA 6F 3F 67 11 09
 *
 *  dat=0818  len=4:   EA 6F 3F 67
 */


class Block_LZ : public Block
{
protected:
	int				dat;


public:
	virtual int GetBodySize() { return 2; }
	virtual int Output(u8* buf) { buf[0] = (u8)(dat >> 8); buf[1] = (u8)dat; return 2; }
	virtual int Shrink(int newstart,int newstop)
	{
		int newdat = (dat + newstart - start);
		if(newdat > 0xFFFF)		return 1;

		dat = newdat;
		start = newstart;
		stop = newstop;
		len = stop - start;
		return 0;
	}
	virtual Block* Dup()	{	return (new Block_LZ(*this));		}

	static void Build(u8 type,BlockList& lst,const u8* src,int srclen)
	{
		Block_LZ tmp;
		tmp.BuildBlocks(type,lst,src,srclen,3,0xFFFF);
	}

	virtual int Decompress(int len,const u8* src,u8* dst,int& dstpos)
	{
		int from = (src[0] << 8) | src[1];
		DoDecompress(from,len,dst,dstpos);
		return 2;
	}


protected:
	virtual Block_LZ* InnerDup()	{	return (new Block_LZ(*this));		}
	void BuildBlocks(u8 type,BlockList& lst,const u8* src,int srclen,int minsize,int mxstrt)
	{
		Block_LZ*			bk;

		int					i, j;
		int					len;

		int					bestlen;
		int					beststrt;

		int					justblocked;
		int					adj;
		int					bestadj;

		i = 1;
		justblocked = 0;

		while(i < srclen)
		{
			bestadj = 0;
			bestlen = minsize - 1;

			for(j = 0; j < i; ++j)
			{
				if(j > mxstrt)		break;
				
				for(len = 0; (len+i < srclen) && (src[len+j] == src[len+i]); ++len);

				adj = 0;
				if(justblocked && len)
				{
					for(; (j-adj >= 0) && (src[i-adj] == src[j-adj]); ++adj);
					--adj;
					len += adj;
					if(len < minsize)
						continue;
				}

				if(((adj == bestadj) && (len > bestlen)) || (adj > bestadj))
				{
					bestlen = len;
					beststrt = j - adj;
					bestadj = adj;
				}
			}

			if(bestlen >= minsize)
			{
				bk =			InnerDup();
				bk->type =		type;
				bk->start =		i - bestadj;
				bk->stop =		i - bestadj + bestlen;
				bk->len =		bestlen;
				bk->dat =		beststrt;
				
				if(bk->Shrink(bk->start,bk->stop))
				{
					delete bk;
					++i;
					justblocked = 0;
				}
				else
				{
					lst.InsertBlock(bk);
					i = bk->stop;
					justblocked = 1;
				}
			}
			else
			{
				++i;
				justblocked = 0;
			}
		}
	}

	
	static void DoDecompress(int from,int len,u8* dst,int& dstpos)
	{
		if(from < 0)		return;
		if(from >= dstpos)	return;

		int i;
		if(dst)
		{
			for(i = 0; i < len; ++i)
				dst[dstpos+i] = dst[from+i];
		}
		
		dstpos += len;
	}
};

#endif