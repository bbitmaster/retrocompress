/*
 *	Compresch - compression library
 *  Copyright 2008 Disch
 *  See license.txt for details
 */


#ifndef __COMPRESCH_TYPES_H__
#define __COMPRESCH_TYPES_H__

typedef	unsigned char		u8;
typedef	unsigned short		u16;

class						Block;
class						BlockList;

#endif