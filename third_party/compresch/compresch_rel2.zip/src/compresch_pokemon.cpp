/*
 *	Compresch - compression library
 *  Copyright 2008 Disch
 *  See license.txt for details
 */


#include <list>
#include <memory.h>
#include "compresch_pokemon.h"

#include "block.h"
#include "blocklist.h"

#include "block_rle.h"
#include "block_rlealternate.h"
#include "block_zero.h"
#include "block_hybridlz.h"
#include "block_hybridlzbitrev.h"
#include "block_hybridlzrev.h"

int Compresch_Pokemon::WorstCompressSize(int srclen)
{
	return Compresch_StdBlock::WorstCompressSize(srclen);
}

int Compresch_Pokemon::Compress(const u8* src,int srclen,u8* dst)
{
	BlockList		blocks;

	Block_RLE::Build(				1 ,blocks,src,srclen);
	Block_RLEAlternate::Build(		2 ,blocks,src,srclen);
	Block_Zero::Build(				3 ,blocks,src,srclen);
	Block_HybridLZ::Build(			4 ,blocks,src,srclen);
	Block_HybridLZBitRev::Build(	5 ,blocks,src,srclen);
	Block_HybridLZRev::Build(		6 ,blocks,src,srclen);

	return Compresch_StdBlock::CrunchAndOutput(blocks,src,srclen,dst);
}

int Compresch_Pokemon::Decompress(const u8* src,int srclen,u8* dst)
{
	Block* blocks[6] = {	new Block_RLE,
							new Block_RLEAlternate,
							new Block_Zero,
							new Block_HybridLZ,
							new Block_HybridLZBitRev,
							new Block_HybridLZRev
						};

	return Compresch_StdBlock::Decompress(src,srclen,dst,blocks);
}