/*
 *	Compresch - compression library
 *  Copyright 2008 Disch
 *  See license.txt for details
 */


#ifndef __BLOCK_H__
#define __BLOCK_H__

class Block
{
public:
	virtual		~Block() { }
	virtual		int		GetBodySize()=0;
	virtual		int		Output(u8* buf)=0;
	virtual		int		Shrink(int newstart,int newstop)=0;
	virtual		Block*	Dup()=0;

	virtual		int		Decompress(int len,const u8* src,u8* dst,int& dstpos) = 0;

	virtual		int		CanShrink(int newstart,int newstop)
	{
		Block* blk = Dup();
		int ret = !blk->Shrink(newstart,newstop);
		delete blk;
		return ret;
	}
	
	virtual		void	DropLen(int newlen) { Shrink(start,start+newlen); }

	u8			type;
	int			start;
	int			stop;
	int			len;

	int			tradeoff;		// only used for fast compression
};


#endif
