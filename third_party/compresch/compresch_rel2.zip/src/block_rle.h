/*
 *	Compresch - compression library
 *  Copyright 2008 Disch
 *  See license.txt for details
 */


#ifndef __BLOCK_RLE_H__
#define __BLOCK_RLE_H__

/*
 *	RLE -- Basic RLE.  1-byte value to repeat
 *
 *  dat=61  len=5:  61 61 61 61 61
 */


class Block_RLE : public Block
{
protected:
	u8				dat;


public:
	virtual int GetBodySize() { return 1; }
	virtual int Output(u8* buf) { buf[0] = dat; return 1; }
	virtual int Shrink(int newstart,int newstop)
	{
		start = newstart;
		stop = newstop;
		len = stop - start;
		return 0;
	}
	virtual Block* Dup()	{	return (new Block_RLE(*this));		}


	/*
	 *	Build all possible blocks
	 *	  RLE (1 byte repeated:  13 13 13 13 13 13)
	 *    minimum length:  2
	 */
	static void	Build(u8 type,BlockList& lst,const u8* src,int srclen)
	{
		Block_RLE*		bk;

		int i, j;
		int len;
		u8 run;

		i = 0;
		while(i < srclen)
		{
			run = src[i];
			for(j = i+1; j < srclen; ++j)
			{
				if(src[j] != run)		break;
			}

			len = j-i;
			if(len >= 2)
			{
				bk = new Block_RLE;
				bk->type =		type;
				bk->start =		i;
				bk->stop =		j;
				bk->len =		len;
				bk->dat =		run;

				lst.InsertBlock(bk);
			}

			i = j;
		}
	}


	/*
	 *	Decompression
	 */
	virtual int Decompress(int len,const u8* src,u8* dst,int& dstpos)
	{
		if(dst)
		{
			while(len > 0)
			{
				dst[dstpos] = src[0];
				--len;
				++dstpos;
			}
		}
		else
			dstpos += len;

		return 1;
	}
};

#endif