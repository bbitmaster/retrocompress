
==========================
==      Compresch       ==
==========================

Windows demo/testing binary
Release 2 -- WIP (no official version number yet)


====
==  Who?

   Kirby Compression info (and a decompressor I used for testing) was
provided by Parasyte.  Encouragement provided by bbitmaster and various
cats in #rom-hacking.  The actual library was coded by Disch... though he
did not really RE any of the compression formats.


====
==  What?

   Compresch is a library for decompressing/recompressing data.  It covers
(or at least will cover) formats common among SNES, GB and even NES games.
Similar to FuSoYa's Lunar Compress (hereon "LC").

   It started as a utility for Kirby's Adventure and Kirby Super Star,
whose format was apparently not supported by LC.  After the project was
underway, it was brought to my attention that many formats covered by LC
were very similar to the Kirby compression... and so I made it one of my goals
to support as many of those as possible.


====
==  Why?

   Partly because LC is closed source... but also because LC is only
available as a DLL module.  Which means it can only be used on Windows
platforms or by editors for Windows.  With the direction Windows is heading
with Vista... and with how GOOD Linux and MacOS have been looking lately --
one of my personal goals is to get away from (and help to get other people
to get away from) Windows-only programming completely.  Cross platform
alternatives are ALWAYS a good option.

   But mainly... because it's fun for me!  I get a kick out of
the "behind-the-scenes" programming stuff.  UIs and building controls and
interfaces and whatnot always bore me... but number crunching and calculations
are just so much fun!  =D



====
==  How?

   I slapped together a CLI for the utility.  It's not really meant to be a
standalone program, but is meant to be more of a library for editor authors.
As such, the CLI is rather clunky -- but I guess it works.

Usage:
compresch <flags> <inputfile> <outputfile> <offset> <format> <formatsub>

flags:
d - decompress (exclude to compress)
i - insert (exclude to overwrite existing output file -- ignored when decompressing)
p - pause before exit

to use none of the above flags, simply use "-"

offset, format, and formatsub are values in hex.  formatsub is currently unused, but
must be present (use 0).  format can be one of the following to select which format
to use:

0 = Kirby's Adventure / Kirby Super Star levels
1 = Pokemon Gold/Silver graphics

See docs for format details


Example:  to decompress pokemon gold graphics at offset $5B2AD:

    compresch d pokemon_gold.gbc graphics.bin 5B2AD 1 0

Then to recompress graphics to a seperate file:

    compresch - graphics.bin compressed.bin 0 1 0

Or... to recompress and insert back in the ROM (BE CAREFUL NOT TO OVERFLOW)

    compresch i graphics.bin pokemon_gold.gbc 5B2AD 1 0


   Alternatively, if you do not want to mess with the CLI, you can just run the exe
with no arguments and follow the prompts.



====
==  License?

   Artistic License 2.0.  See license.txt for details.

In a nutshell:

 1)  This library is open source.  If you are distributing the lib, you must
     also distribute the source (or inform people where the source may be
     obtained).

 2)  You may make and distribute modifications to this library.  These
     modifications do not have to be open source, but source should be available
     to me at my request so that your additions/modifications can be made to
     the original (this is highly simplified and isn't always the case.  See
     license.txt for details).  Basically, if you want to release modified
     versions of this library, it's easiest if you just release them under
     this license, although you don't HAVE to.

 3)  You may write software which makes use of this unmodified library (like
     say, an editor that uses this library to decompress and recompress data).
     This program does not have to be open source, and you will not have any
     licensing restrictions on your program (at least none imposed by this
     library).


If you have concerns or questions regarding modifications, improvements, or
whatnot.  Feel free to contact me at dischmeister@gmail.com.  Though I don't
check my e-mail very often -- so it's probably best to find where I "hang out"
online and contact me via a forum PM or on IRC or whatever.  Currently I spend
most my time in #rom-hacking on irc.esper.net and on the romhacking.net forums.