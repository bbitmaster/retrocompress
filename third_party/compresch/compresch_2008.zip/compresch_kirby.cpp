
#include <list>
#include <memory.h>
#include "compresch_kirby.h"

#include "block.h"
#include "blocklist.h"

#include "block_rle.h"
#include "block_rletwo.h"
#include "block_rleplus.h"
#include "block_lz.h"
#include "block_lzbitrev.h"
#include "block_lzrev.h"


int Compresch_Kirby::WorstCompressSize(int srclen)
{
	// worse case compression is that nothing can be compressed

	int ret = (srclen / 1024) * (1024 + 2);
	srclen %= 1024;

		 if(srclen > 32)	ret += 2 + srclen;
	else if(srclen > 0)		ret += 1 + srclen;

	return ret;
}

int Compresch_Kirby::Compress(const u8* src,int srclen,u8* dst)
{
	// 1) build the blocks
	BlockList		blocks;

	Block_RLE::Build(		1 ,blocks,src,srclen);
	Block_RLETwo::Build(	2 ,blocks,src,srclen);
	Block_RLEPlus::Build(	3 ,blocks,src,srclen);
	Block_LZ::Build(		4 ,blocks,src,srclen);
	Block_LZBitRev::Build(	5 ,blocks,src,srclen);
	Block_LZRev::Build(		6 ,blocks,src,srclen);

	// 2) break the blocks down
	blocks.CrunchList(1,32,1024,srclen);	// 1 byte block header -- 2 bytes after len of 32 -- max len of 1024


	// 3) output the blocks
	int dstpos = 0;
	int srcpos = 0;
	Block* blk;

	while(srcpos < srclen)
	{
		blk = blocks.PopFront();

		if(!blk)
		{
			dstpos += OutputRawBlock(&src[srcpos],&dst[dstpos],srclen - srcpos);
			srcpos = srclen;
		}
		else
		{
			if(blk->start > srcpos)
				dstpos += OutputRawBlock(&src[srcpos],&dst[dstpos],blk->start - srcpos);
			dstpos += OutputBlock(blk,&dst[dstpos]);
			srcpos = blk->stop;
			delete blk;
		}
	}

	// 4) done!
	return dstpos;
}

int Compresch_Kirby::OutputBlock(Block* blk,u8* dst)
{
	if(blk->len > 32)
	{
		dst[0] = 0xE0 | (blk->type << 2) | (((blk->len - 1) >> 8) & 3);
		dst[1] = (blk->len - 1) & 0xFF;
		return 2 + blk->Output(&dst[2]);
	}
	dst[0] = (blk->type << 5) | ((blk->len - 1) & 0x1F);
	return 1 + blk->Output(&dst[1]);
}

int Compresch_Kirby::OutputRawBlock(const u8* src,u8* dst,int len)
{
	int ret = 0;
	while(len > 1024)
	{
		dst[0] = 0xE3;
		dst[1] = 0xFF;
		memcpy(&dst[2],src,1024);
		dst += 1024 + 2;
		src += 1024;
		ret += 1024 + 2;
		len -= 1024;
	}

	if(len > 32)
	{
		dst[0] = 0xE0 | (((len - 1) >> 8) & 3);
		dst[1] = (len - 1) & 0xFF;
		memcpy(&dst[2],src,len);
		return ret + len + 2;
	}
	
	dst[0] = ((len - 1) & 0x1F);
	memcpy(&dst[1],src,len);
	return ret + len + 1;
}
