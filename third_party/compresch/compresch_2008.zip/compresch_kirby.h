
#include "compresch_types.h"


class Block;


class Compresch_Kirby
{
public:
	static int			Compress(const u8* src,int srclen,u8* dst);
	static int			WorstCompressSize(int srclen);

protected:
	static int			OutputRawBlock(const u8* src,u8* dst,int len);
	static int			OutputBlock(Block* blk,u8* dst);
};