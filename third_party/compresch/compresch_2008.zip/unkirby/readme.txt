This is a utility written by Parasyte in 2004

usage:

unkirby <inputfile> <offset> <outputfile>


example to get level 1-1 from Kirby's Adventure:

unkirby kirby.nes 1289D output.bin



I got this package from bbit on IRC.  I corrected a bug in unkirby.c that made it crash when it hit
bit-reversed blocks.  Aside from that the source is as I received it.



original__unkirby.exe is the original exe I received (with the above mentioned bug).  It produces
logfiles... which I couldn't reproduce in my bugfix since the source for that doesn't appear to be in the
files I was given.