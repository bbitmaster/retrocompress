
#ifndef			__BLOCKLLIST_H__
#define			__BLOCKLLIST_H__


typedef		std::list<Block*>			List;
typedef		List::iterator				iter;

class BlockList
{
public:
						BlockList();
						~BlockList();

	void				InsertBlock(Block* blk);
	void				EmptyInternalList();

	Block*				PopFront();
	
	static void			EmptyList(List& lst);

	void				CrunchList(int blocksize,int extrabyteafter,int lenmax,int endofdata);
	void				CrunchList_Fast(int lenmax);

protected:
	List									mLst;
	void				CopyList(List& dest,List& src);

	void				KillPointlessBlocks();
};


#endif