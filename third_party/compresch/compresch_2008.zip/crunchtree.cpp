
#include <list>
#include "compresch_types.h"
#include "block.h"
#include "blocklist.h"
#include "crunchtree.h"

CrunchTree::CrunchTree()
{
	top = 0;
}

CrunchTree::~CrunchTree()
{
	Destroy();
}

void CrunchTree::Destroy()
{
	if(top)
		delete top;

	top = 0;
	ends.clear();
}

int CrunchTree::CalcBlockBytes(Block* blk)
{
	int coarse, fine;
	coarse =	blk->len / nLenMax;
	fine =		blk->len % nLenMax;

	coarse *=	blk->GetBodySize() + nBytesPerBlock + 1;
	if(fine)
		coarse += blk->GetBodySize() + nBytesPerBlock + (fine > nExtraByteAfter);

	return coarse;
}

int CrunchTree::CalcRawBytes(int len)
{
	int coarse, fine;
	coarse =	len / nLenMax;
	fine =		len % nLenMax;

	coarse *=	nLenMax + nBytesPerBlock + 1;
	if(fine)
		coarse += fine + nBytesPerBlock + (fine > nExtraByteAfter);

	return coarse;
}

void CrunchTree::Crunch(List& lst,int bytesperblock,int extrabyteafter,int lenmax,int endofdata)
{
	if(lst.empty())		// empty list is empty
		return;

	nBytesPerBlock =		bytesperblock;
	nExtraByteAfter =		extrabyteafter;
	nLenMax =				lenmax;

	// clear the tree (if one exists -- it shouldn't, but just in case)
	Destroy();

	// build tree from top down!
	top = new CrunchNode(0);
	ends.push_back(top);

	iter i;
	for(i = lst.begin(); i != lst.end(); ++i)
	{
		// pad and clean chains up to this block's starting point
		PadAndCleanChains((*i)->start);

		// then try putting this block in the chains
		ChainBlock(*i);
	}

	// after you do that with all the blocks, pad them to the end of data and clean
	PadAndCleanChains(endofdata);

	// here, any of the nodes in 'ends' are all best-case compression paths and should all be completely equal
	//   and in fact... if I'm cleaning up right, this should mean that I'm guaranteed that 'ends' only contains
	//   one node.

	List	bestlist;
	BuildBestList(bestlist,ends.front());

	// bestlist is now compiled -- kill the original list and replace it
	BlockList::EmptyList(lst);
	lst.swap(bestlist);


	// and that's all she wrote!
}

void CrunchTree::PadAndCleanChains(int start)
{
	// this function takes the given starting point and checks it against each chain's ending point
	//   since the block list is stored in ascending order of starting points -- once we reach any given
	//   starting point... any chains that are not to the current starting point can only reach the point
	//   with a raw block.
	//
	// since raw blocks are big and ugly, this is where most chains will reach their dead end and be removed
	//   from the 'ends' list.

	NodeIter i, j;

	// first... pad them all to starting point
	for(i = ends.begin(); i != ends.end(); ++i)
	{
		if((*i)->dat.padstop >= start)		// does not need padding
			continue;

		(*i)->dat.padbytes =	(*i)->dat.bytes + CalcRawBytes(start - (*i)->dat.stop);
		(*i)->dat.padstop =		start;
	}


	// now run through and clean bad chains
	//  a chain is bad if another chain reaches as far or further in as many or fewer bytes
	for(i = ends.begin(); i != ends.end(); ++i)
	{
		for(j = ends.begin(); j != ends.end(); ++j)
		{
			if(i==j)		// don't compare one chain to itself
				continue;

			// we will be testing j for removal -- not i
			if((*j)->dat.padstop  >  (*i)->dat.padstop)			continue;
			if((*j)->dat.padbytes <  (*i)->dat.padbytes)		continue;
			if((*j)->dat.padbytes == (*i)->dat.padbytes)
			{
				// don't remove j if it extends further than i before padding
				//  since the padding could be making them look equal
				if((*j)->dat.stop > (*i)->dat.stop)				continue;
			}


			// if we got here, j is a useless chain .. remove it from ends list
			j = ends.erase(j);
			--j;
		}
	}
}

void CrunchTree::ChainBlock(Block* blk)
{
	// this is where we try putting 'blk' in each chain (or rather where each chain is split by 'blk')
	//   note we only have to test against existing chains

	Block* tmp = blk->Dup();		//  we'll need to shuffle it around and crap, so dup it
	CRUNCH cr;
	int rem;

	cr.blk =		blk;

	NodeIter	i;
	for(i = ends.begin(); i != ends.end(); ++i)
	{
		// does this chain go further than this block does?  If so -- no point in adding this block to
		//  the chain
		if((*i)->dat.padstop >= blk->stop)		continue;

		// refresh copy of block
		*tmp = *blk;

		// does this chain go *into* this block?  If so -- try pushing this block forward so it starts where
		//  the chain left off
		if((*i)->dat.padstop > blk->start)
		{
			if(tmp->Shrink((*i)->dat.padstop,tmp->stop))		// shrink failed, can't add to this chain
				continue;
		}
		cr.start =	tmp->start;

		// now we're going to potentially fork several chains here.  There are many ways we need to attempt to apply
		//   this block:
		//  1)  In full  (full len)
		//  2)  Just below extra byte boundaries (assuming it's above those bounds)
		//  3)  Just below extra block boundaries (assuming it's above those)

		//  testing for all 3 can be done in this neat little while loop:

		while(tmp->len > 0)
		{
			// in full, or just below extra block bound
			cr.stop =	tmp->stop;
			cr.bytes =	CalcBlockBytes(tmp) + (*i)->dat.padbytes;
			AddNode(*i,cr);			// AddNode adds to the front of the list, so as not to disturb this for loop

			rem = tmp->len % nLenMax;
			if(!rem)		rem = nLenMax;

			if(rem > nExtraByteAfter)
			{
				// just below extra byte bound
				tmp->DropLen(tmp->len - rem + nExtraByteAfter);
				cr.stop =	tmp->stop;
				cr.bytes =	CalcBlockBytes(tmp) + (*i)->dat.padbytes;
				AddNode(*i,cr);

				rem = tmp->len % nLenMax;
				if(!rem)	rem = nLenMax;
			}

			tmp->DropLen(tmp->len - rem);
		}
	}

	delete tmp;
}

void CrunchTree::AddNode(CrunchNode* parent,CRUNCH& cr)
{
	CrunchNode* nd = new CrunchNode(parent);
	nd->dat = cr;
	nd->dat.padbytes = nd->dat.bytes;
	nd->dat.padstop = nd->dat.stop;

	parent->dn.push_front(nd);
	ends.push_front(nd);
}

void CrunchTree::BuildBestList(List& lst,CrunchNode* node)
{
	Block* blk;
	Block* tmp;
	int rem;

	while(node)
	{
		if(node->dat.blk)
		{
			blk = node->dat.blk->Dup();
			blk->Shrink(node->dat.start,node->dat.stop);

			while(blk->len > nLenMax)
			{
				rem = blk->len % nLenMax;
				if(!rem)	rem = nLenMax;

				tmp = blk->Dup();

				blk->DropLen(blk->len - rem);
				tmp->Shrink(blk->stop,tmp->stop);

				lst.push_front(tmp);
			}
			lst.push_front(blk);
		}

		node = node->up;
	}
}
