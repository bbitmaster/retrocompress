
Compresch
Copyright 2008  -  Disch


WIP compressor (and eventually decompressor) for various games



Source can be considered to be public domain.  Feel free to do whatever the hell you want with it.


exe usage:

didn't feel like making a proper commandline parser.  So it just looks for
C:\kirbyin.bin
and dumps the compressed file to
C:\kirbyout.bin

Probably shouldn't try it on files that are very large (> 64KB)



/unkirby/ was not written by me so above does not apply.