
#include <stdio.h>
#include "compresch_kirby.h"

int main()
{
	FILE* file = fopen("C:\\kirbyin.bin","rb");
	if(!file)
		return 1;

	int raw_size;
	int com_size;

	fseek(file,0,SEEK_END);
	raw_size = ftell(file);
	fseek(file,0,SEEK_SET);

	com_size = Compresch_Kirby::WorstCompressSize(raw_size);

	u8* raw = new u8[raw_size];
	u8* com = new u8[com_size];

	fread(raw,1,raw_size,file);
	fclose(file);

	com_size = Compresch_Kirby::Compress(raw,raw_size,com);
	delete[] raw;

	file = fopen("C:\\kirbyout.bin","wb");
	if(file)
	{
		fwrite(com,1,com_size,file);
		fputc(0xFF,file);
		fclose(file);
	}
	delete[] com;


	return 0;
}