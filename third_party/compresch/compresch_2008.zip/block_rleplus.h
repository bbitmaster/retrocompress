
#ifndef __BLOCK_RLEPLUS_H__
#define __BLOCK_RLEPLUS_H__

class Block_RLEPlus : public Block
{
protected:
	u8				dat;


public:
	int GetBodySize() { return 1; }
	int Output(u8* buf) { buf[0] = dat; return 1; }
	int Shrink(int newstart,int newstop)
	{
		dat = (u8)(dat + newstart - start);
		start = newstart;
		stop = newstop;
		len = stop - start;
		return 0;
	}
	Block* Dup()	{	return (new Block_RLEPlus(*this));		}

	/*
	 *	Build all possible blocks
	 *	  RLE (1 byte incrementing:  13 14 15 16 17 18)
	 *    minimum length:  2
	 */
	static void	Build(u8 type,BlockList& lst,const u8* src,int srclen)
	{
		Block_RLEPlus*		bk;

		int					i, j;
		int					len;
		u8					run;
		u8					currun;

		i = 0;
		while(i < srclen)
		{
			run = src[i];
			currun = run+1;
			for(j = i+1; j < srclen; ++j)
			{
				if(src[j] != currun)	break;
				++currun;
			}

			len = j-i;
			if(len >= 2)
			{
				bk = new Block_RLEPlus;
				bk->type =		type;
				bk->start =		i;
				bk->stop =		j;
				bk->len =		len;
				bk->dat =		run;

				lst.InsertBlock(bk);
			}

			i = j;
		}
	}
};

#endif