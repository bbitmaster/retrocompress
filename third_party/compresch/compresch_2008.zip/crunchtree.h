
#ifndef			__CRUNCHTREE_H__
#define			__CRUNCHTREE_H__


struct CRUNCH
{
	Block*		blk;
	int			start;
	int			stop;
	int			bytes;

	int			padstop;	// stop after some raw padding
	int			padbytes;	// bytes after raw padding
};

class CrunchNode;
typedef std::list<CrunchNode*>		NodeList;
typedef NodeList::iterator			NodeIter;

class CrunchNode
{
public:
	CrunchNode(CrunchNode* parent)
	{
		up =			parent;
		dat.blk =		0;
		dat.start =		0;
		dat.stop =		0;
		dat.bytes =		0;
		dat.padstop =	0;
		dat.padbytes =	0;
	}
	~CrunchNode()
	{
		while(!dn.empty())
		{
			delete dn.front();
			dn.pop_front();
		}
	}

	CrunchNode*		up;
	NodeList		dn;
	CRUNCH			dat;
};


class CrunchTree
{
public:
	CrunchTree();
	~CrunchTree();

	void			Crunch(List& lst,int bytesperblock,int extrabyteafter,int lenmax,int endofdata);
	void			Destroy();

protected:

	CrunchNode*		top;
	NodeList		ends;
	
	int					nBytesPerBlock;
	int					nExtraByteAfter;
	int					nLenMax;

	int					CalcBlockBytes(Block* blk);
	int					CalcRawBytes(int len);

	void				PadAndCleanChains(int start);
	void				ChainBlock(Block* blk);
	void				BuildBestList(List& lst,CrunchNode* node);

	inline void			AddNode(CrunchNode* parent,CRUNCH& cr);
};

#endif