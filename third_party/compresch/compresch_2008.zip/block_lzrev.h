
#ifndef __BLOCK_LZREV_H__
#define __BLOCK_LZREV_H__

class Block_LZRev : public Block
{
protected:
	u16				dat;


public:
	int GetBodySize() { return 2; }
	int Output(u8* buf) { buf[0] = (u8)(dat >> 8); buf[1] = (u8)dat; return 2; }
	int Shrink(int newstart,int newstop)
	{
		dat = (u16)(dat - newstart + start);
		start = newstart;
		stop = newstop;
		len = stop - start;
		return 0;
	}
	Block* Dup()	{	return (new Block_LZRev(*this));		}

	/*
	 *	Build all possible blocks
	 *	  LZ (straight copy from source in reverse order)
	 *    minimum length:  3
	 */
	static void	Build(u8 type,BlockList& lst,const u8* src,int srclen)
	{
		Block_LZRev*		bk;

		int					i, j;
		int					len;
		int					mxstart;

		int					bestlen;
		u16					beststrt;

		mxstart = srclen - 2;
		if(mxstart > 0xFFFF)
			mxstart = 0xFFFF;		// dat is only 2 bytes, can't address more than 16-bits

		i = 1;
		while(i < srclen)
		{
			bestlen = 2;	// actual lengths must be >= 3

			for(j = 1; j < i; ++j)
			{
				if(j > mxstart)		break;

				for(len = 0; j-len >= 0; ++len)
				{
					if(src[j-len] != src[len+i])
						break;
				}

				if(len > bestlen)
				{
					bestlen = len;
					beststrt = (u16)j;
				}
			}

			if(bestlen >= 3)
			{
				bk =			new Block_LZRev;
				bk->type =		type;
				bk->start =		i;
				bk->stop =		i+bestlen;
				bk->len =		bestlen;
				bk->dat =		beststrt;
				
				lst.InsertBlock(bk);

				i += bestlen;
			}
			else
				++i;
		}
	}
};

#endif